<?php
defined('_JEXEC') or die;

use Joomla\CMS\Installer\InstallerScript;

/**
 * Installation script for com_produccion
 * 
 * Optimized for Joomla 5.3.3
 * Completely safe installer - no ACL operations
 */
class Com_ProduccionInstallerScript extends InstallerScript
{
    protected $minimumJoomla = '5.3.0';
    protected $minimumPhp = '8.1.0';
    protected $extension = 'com_produccion';
    
    public function install($adapter) { 
        return true; 
    }
    
    public function update($adapter) { 
        return true; 
    }
    
    public function uninstall($adapter) { 
        return true; 
    }
    
    public function preflight($type, $adapter) { 
        return true; 
    }
    
    public function postflight($type, $adapter) { 
        return true; 
    }
}